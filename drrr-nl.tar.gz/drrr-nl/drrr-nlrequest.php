<?php
/*
Plugin Name: Drrr News Letter Request
Plugin URI: http://wordpress/
Description: Allows the visitor to request to receive the newsletter. After install, create a public page with the short code: [drrrnl_form] for the form and an admin page with the short code [drrrnl_list] for the list. 
Author: drrr
Version: 1.0
Author URI: http://wordpress/
 */

/* Contact Form Function treatment */
function drrrnl_form_treatment(){
	wp_register_style('drrr_nl.css',plugin_dir_url(__FILE__).'drrr_nl.css',array(),false);
	wp_enqueue_style('drrr_nl.css');
	$drrrnl_post_title = 'Drrr News Letter Request';
	$drrrnl_lastname_field = 'drrrnl_LastName';
	$drrrnl_firstname_field = 'drrrnl_FirstName';
	$drrrnl_email_field = 'drrrnl_Email';
	$drrrnl_submit_field = 'drrrnl_submit';
	$t_form = '';
	$drrrnl_invalid = -1;
	/* Verify if we are after the submission of the form */
	if(isset($_POST[$drrrnl_submit_field])) {
		$drrrnl_invalid = 0;
		if(isset($_POST[$drrrnl_lastname_field])){
			$drrrnl_lastname = sanitize_text_field($_POST[$drrrnl_lastname_field]);
			if(strlen($drrrnl_lastname) < 2){
				$drrrnl_invalid = 1;
				$t_form .= 'Last Name must be at least 2 alphanum characters.<br/>';
			}
			else{
				$t_form .= $drrrnl_lastname; 
				$t_form .= ' ';
			}
		}
		else{
			$t_form .= "Last name is a mandatory field<br/>";
			$drrrnl_invalid = 1;
		}
		if(isset($_POST[$drrrnl_firstname_field])){
			$drrrnl_firstname = sanitize_text_field($_POST[$drrrnl_firstname_field]);
			if(strlen($drrrnl_firstname) < 2){
				$drrrnl_invalid = 1;
				$t_form .= 'First Name must be at least 2 alphanum characters.<br/>';
			}
			else{
				$t_form .= $drrrnl_firstname; 
				$t_form .= ' ';
			}
		}
		else {
			$t_form .= "First name is a mandatory field<br/>";
			$drrrnl_invalid = 1;
		}
		if(isset($_POST[$drrrnl_email_field])){
			$drrrnl_email = sanitize_text_field($_POST[$drrrnl_email_field]);
			if(!is_email($drrrnl_email)){
				$t_form .= "Invalid email address!<br/>";
				$drrrnl_invalid = 1;
			}
			elseif(drrrnl_email_already_in_use($drrrnl_email,$drrrnl_post_title) == true){
				$t_form .= " : email ";
				$t_form .= $drrrnl_email;
				$t_form .= " already receives the newsletter";
				$drrrnl_invalid = 1;
			}
		}
		else {
			$t_form .= "Email is a mandatory field<br/>";
			$drrrnl_invalid = 1;
		}
		if(isset($_POST['drrrnl_Pro'])){
			$drrrnl_pro = " (professional)";
		}
		else $drrrnl_pro = "";
		$t_form .= $drrrnl_pro;
		if($drrrnl_invalid == 0){
			$t_form = '<p> thanks for your interest '.$t_form;
			$t_form .= '<br/>Request sent to the site administrator to send the newsletter to:<br/>';
			$t_form .= $drrrnl_email;
			$t_form .= '</p>';
			drrrnl_save_alert_post($drrrnl_lastname,$drrrnl_firstname,$drrrnl_email,$drrrnl_pro,$drrrnl_post_title);
			drrrnl_send_alert_to_admin($drrrnl_lastname,$drrrnl_firstname,$drrrnl_email,$drrrnl_pro);
			return ($t_form);
		}
	}
	if($drrrnl_invalid != 0){
		ob_start();
		include(__DIR__.'/drrr-nlpage.php');
		$t_form .= ob_get_contents();
		ob_end_clean();
		return($t_form);
	}
}

/* Save the contact details as a wordpress post */
function drrrnl_save_alert_post($lastname,$firstname,$email,$pro,$title){
	$drrrnl_message = $lastname." ";
	$drrrnl_message .= $firstname.", ";
	$drrrnl_message .= $email.", ";
	$drrrnl_message .= $pro;
	$drrrnl_message .= ", wants to receive the newsletter";

	wp_insert_post(
		array(
			'post_title'=> $title,
			'post_status'=>'publish',
			'post_content' => $drrrnl_message,
			'post_content_filtered' => $email)
		);

}

/* list the existing contacts emails */
function drrrnl_requests_list($title)
{
	$drrrnl_list = '<table class="drrrnl_list"><tr>';
	$drrrnl_bottom = '</table>';
	$drrrnl_args =	array('numberposts' => -1,
		'post_title' => $title
		);
	$drrrnl_posts = get_posts($drrrnl_args);
	if($drrrnl_posts == null || empty($drrrnl_posts)){
		$drrrnl_list .= $drrrnl_bottom;
		return $drrrnl_list;
	}
	foreach($drrrnl_posts as $drrrnl_post => $drrrnl_val){
		if($drrrnl_val != null && !empty($drrrnl_val)){
			$drrrnl_list .= '<tr><td>';
			$drrrnl_list .= $drrrnl_val->post_content_filtered;
			$drrrnl_list .= '</td></tr>';
		}
	}
	$drrrnl_list .= $drrrnl_bottom;
	return $drrrnl_list;
}

/* check if the this email address already exists in the contacts list */
function drrrnl_email_already_in_use($email,$title)
{
	$drrrnl_args =	array('numberposts' => -1,
		'post_title' => $title,
		'post_content_filtered' => $email);
	$drrrnl_posts = get_posts($drrrnl_args);
	if($drrrnl_posts == null || empty($drrrnl_posts)){
		return false;
	}
	foreach($drrrnl_posts as $drrrnl_post => $drrrnl_val){
		if($drrrnl_val != null && !empty($drrrnl_val)){
			if(	$drrrnl_val->post_content_filtered == $email)
				return true;
		}
	}
	return false;
}


/* Send alert mail to admin user */
function drrrnl_send_alert_to_admin($lastname,$firstname,$email,$pro){
	$drrrnl_message = "A new user newsletter request has been sent by:";
	$drrrnl_message .= " ".$lastname;
	$drrrnl_message .= " ".$firstname;
	$drrrnl_message .= " ".$email;
	$drrrnl_message .= " (".$pro;
	$drrrnl_message .= ")";
	wp_mail(get_option( 'admin_email' ), 'User Newsletter Request', $drrrnl_message, "", ""); 
}

add_shortcode('drrrnl_form','drrrnl_form_treatment');
add_shortcode('drrrnl_list','drrrnl_requests_list');
?>
