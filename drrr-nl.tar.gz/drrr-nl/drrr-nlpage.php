<p class="drrrnl_form">Contact details to receive the newsletter</p>
<form action=<?php echo (get_permalink()); ?> id="drrnl_form" method="post">
	<table class="drrrnl_form">
	<tr>
		<td><label for="drrrnl_LastName">Last Name</label></td>
		<td><input type="text" name="drrrnl_LastName" id="drrrnl_LastName" class="requiredField" /></td>
	</tr>
	<tr>
		<td><label for="drrrnl_FirstName">First Name</label></td>
		<td><input type="text" name="drrrnl_FirstName" id="drrrnl_FirstName" class="requiredField" /></td>
	</tr>
	<tr>
		<td><label for="drrrnl_Email">Email</label></td>
		<td><input type="text" name="drrrnl_Email" id="drrrnl_Email" class="requiredField" /></td>
	</tr>
	<tr>
		<td><label for="drrrnl_Pro">Professional</label></td>
		<td><input type="checkbox" name="drrrnl_Pro" id="drrrnl_Pro" /></td>
	</tr>
	</table>
	<div class="buttons">
		<!-- input type="hidden" name="submitted" id="submitted"/-->
		<button type="submit" name="drrrnl_submit" id="drrrnl_submit">Envoyer</button>
	</div>
</form> 
